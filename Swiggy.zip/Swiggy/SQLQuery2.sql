-- Most Popular Food Types Served by Swiggy Restaurants in Each City
WITH CityFoodCounts AS (
    SELECT 
        City,
        [Food_type],
        COUNT(ID) AS NumberOfRestaurants
    FROM 
        Swiggy_Data
    GROUP BY 
        City, [Food_type]
),
RankedFoodTypes AS (
    SELECT
        City,
        [Food_type],
        NumberOfRestaurants,
        ROW_NUMBER() OVER (PARTITION BY City ORDER BY NumberOfRestaurants DESC) AS rn
    FROM 
        CityFoodCounts
)
SELECT
    City,
    [Food_type],
    NumberOfRestaurants
FROM 
    RankedFoodTypes
WHERE 
    rn = 1;