-- Top Rated Swiggy Restaurants In Percentage
WITH RatingCounts AS (
    SELECT
        COUNT(*) AS TotalRestaurants,
        SUM(CASE WHEN [Avg_ratings] > 4.5 THEN 1 ELSE 0 END) AS Above45Count
    FROM 
        Swiggy_Data
)
SELECT
    'Above 4.5' AS Rating,
    (Above45Count * 100.0 / TotalRestaurants) AS Percentage
FROM 
    RatingCounts
UNION ALL
SELECT
    '4.5 and Below' AS Rating,
    (100 - (Above45Count * 100.0 / TotalRestaurants)) AS Percentage
FROM 
    RatingCounts;