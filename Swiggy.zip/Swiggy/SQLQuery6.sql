-- Get the top 15 areas with the most restaurants in Bangalore
SELECT
	TOP 15
    Area,
    COUNT(*) AS NumberOfRestaurants
FROM
    Swiggy_Data
WHERE
    City = 'Bangalore'
GROUP BY
    Area
ORDER BY
    NumberOfRestaurants DESC;