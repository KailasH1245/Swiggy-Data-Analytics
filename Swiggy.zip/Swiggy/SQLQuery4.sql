-- Distribution of Restaurant Prices on Swiggy
SELECT
    CASE
		WHEN Price BETWEEN 0 AND 150 THEN '0 - 150'
        WHEN Price BETWEEN 151 AND 300 THEN '151 - 300'
        WHEN Price BETWEEN 301 AND 450 THEN '301 - 450'
        ELSE '450+'
    END AS PriceRange,
    COUNT(*) AS NumberOfRestaurants
FROM 
    Swiggy_Data
GROUP BY 
    CASE
		WHEN Price BETWEEN 0 AND 150 THEN '0 - 150'
        WHEN Price BETWEEN 151 AND 300 THEN '151 - 300'
        WHEN Price BETWEEN 301 AND 450 THEN '301 - 450'
        ELSE '450+'
    END
ORDER BY 
    MIN(Price); 