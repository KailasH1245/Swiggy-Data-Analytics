-- Top 15 Areas with Most Restaurants
SELECT 
	TOP 15
    Area,
    COUNT(*) AS NumberOfRestaurants
FROM 
    Swiggy_Data
GROUP BY 
    Area
ORDER BY 
    NumberOfRestaurants DESC;