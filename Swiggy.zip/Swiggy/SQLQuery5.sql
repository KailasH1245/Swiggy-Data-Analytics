-- Calculate the average ratings by area and filter for areas with ratings above 4.5
SELECT
    Area,
    AVG([Avg_ratings]) AS AverageRating
FROM
    Swiggy_Data
GROUP BY
    Area
HAVING
    AVG([Avg_ratings]) > 4.5
ORDER BY
    AverageRating DESC;